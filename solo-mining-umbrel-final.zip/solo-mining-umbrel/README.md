# ⛏ Solo Mining Pool — Umbrel App

App para conectar tus mineros ASICs directamente a tu nodo **Bitcoin Knots** en **Umbrel** sobre **Raspberry Pi 5**.

Mina en solitario: si encuentras un bloque, **la recompensa completa es tuya**.

---

## 📱 Cómo instalar en Umbrel (desde tu celular)

### Paso 1 — Abre Umbrel en Chrome
```
http://[tu-ip-tailscale]
```

### Paso 2 — Agrega este repositorio como Community App Store

1. En Umbrel ve a **App Store**
2. Toca los **tres puntos** `⋮` arriba a la derecha
3. Toca **"Add community app store"**
4. Pega esta URL:
```
https://github.com/gasparin3007be-debug/solo-mining-umbrel
```
5. Toca **Add**

### Paso 3 — Instala la app

1. Busca **"Solo Mining Pool"** en la tienda
2. Toca **Install**
3. Espera 2-3 minutos

### Paso 4 — Configura tus mineros

En cada ASIC (Antminer, Whatsminer, Goldshell, etc.):

| Campo    | Valor                                    |
|----------|------------------------------------------|
| Pool URL | `stratum+tcp://[ip-tailscale]:3333`      |
| Worker   | `minero1.w1`                             |
| Password | `x`                                      |

---

## 📊 Dashboard

Abre en tu celular:
```
http://[ip-tailscale]:4000
```

Verás:
- Hashrate de la red Bitcoin en tiempo real
- Tus workers conectados y su hashrate
- Últimos bloques de la red
- Alerta si encuentras un bloque 🎉

---

## ⚙️ Requisitos

- Umbrel OS en Raspberry Pi 5
- Bitcoin Knots sincronizado (app Bitcoin en Umbrel)
- Tailscale instalado en Umbrel y tu celular
- Mineros ASIC compatibles con protocolo Stratum

---

## 🔧 Puertos usados

| Puerto | Uso                          |
|--------|------------------------------|
| 3333   | Stratum (conexión de ASICs)  |
| 4000   | Dashboard web                |
| 4001   | API interna                  |

---

## ⚠️ Importante

La minería en solitario es como una lotería. Con menos de **1 PH/s** de hashrate, encontrar un bloque puede tomar años. Esta app es para quien quiere conectar sus equipos a su propio nodo sin depender de pools externos.
