#!/usr/bin/env python3
"""
Solo Mining Pool API
Lee datos de Bitcoin Knots + ckpool y los expone al dashboard
"""
import os, json
from pathlib import Path
from datetime import datetime
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import requests

app = FastAPI(title="Solo Mining Pool API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

RPC_HOST   = os.environ.get("RPC_HOST", "bitcoind")
RPC_PORT   = os.environ.get("RPC_PORT", "8332")
RPC_USER   = os.environ.get("RPC_USER", "umbrel")
RPC_PASS   = os.environ.get("RPC_PASS", "")
CKPOOL_LOG = os.environ.get("CKPOOL_LOG", "/data/logs/ckpool")
RPC_URL    = f"http://{RPC_HOST}:{RPC_PORT}"

def rpc(method, params=None):
    try:
        r = requests.post(RPC_URL,
            auth=(RPC_USER, RPC_PASS),
            json={"jsonrpc":"1.0","id":"api","method":method,"params":params or []},
            timeout=6)
        return r.json().get("result")
    except Exception:
        return None

def get_workers():
    workers = {}
    log_dir = Path(CKPOOL_LOG)
    users_dir = log_dir / "users"
    if users_dir.exists():
        for f in users_dir.glob("*"):
            try:
                data = json.loads(f.read_text())
                workers[f.name] = {
                    "name":     f.name,
                    "hashrate": data.get("hashrate5m", 0),
                    "shares":   data.get("shares",    0),
                    "best":     data.get("bestshare", 0),
                    "last_seen": data.get("lastshare", ""),
                }
            except Exception:
                pass
    return workers

def get_blocks_found():
    blocks = []
    log_file = Path(CKPOOL_LOG) / "ckpool.log"
    if log_file.exists():
        lines = log_file.read_text(errors="ignore").splitlines()
        for line in lines:
            if "Solved block" in line or "BLOCK FOUND" in line:
                blocks.append(line.strip())
    return blocks

@app.get("/api/status")
def status():
    info    = rpc("getblockchaininfo") or {}
    mining  = rpc("getmininginfo")    or {}
    network = rpc("getnetworkinfo")   or {}
    workers = get_workers()
    blocks  = get_blocks_found()
    return {
        "timestamp": datetime.utcnow().isoformat(),
        "node": {
            "online":  bool(info),
            "blocks":  info.get("blocks", 0),
            "headers": info.get("headers", 0),
            "synced":  info.get("initialblockdownload") == False,
            "sync_pct": round(info.get("verificationprogress", 0) * 100, 2),
            "chain":   info.get("chain", "main"),
            "version": network.get("subversion", ""),
        },
        "mining": {
            "networkhashps": mining.get("networkhashps", 0),
            "difficulty":    mining.get("difficulty", 0),
            "pooledtx":      mining.get("pooledtx", 0),
        },
        "pool": {
            "workers":      len(workers),
            "worker_list":  list(workers.values()),
            "blocks_found": len(blocks),
            "last_blocks":  blocks[-5:],
        }
    }

@app.get("/api/blocks")
def recent_blocks():
    info = rpc("getblockchaininfo") or {}
    tip  = info.get("blocks", 0)
    blocks = []
    for h in range(tip, max(tip - 10, 0), -1):
        bh = rpc("getblockhash", [h])
        if bh:
            b = rpc("getblock", [bh])
            if b:
                blocks.append({
                    "height": b["height"],
                    "hash":   b["hash"][:20] + "...",
                    "txs":    b["nTx"],
                    "size":   b["size"],
                    "time":   b["time"],
                })
    return {"blocks": blocks}

@app.get("/api/health")
def health():
    return {"ok": True, "ts": datetime.utcnow().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("API_PORT", 4001)))
